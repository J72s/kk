const ytdl = require("ytdl-core");
const strings = require("../strings.json");
const utils = require("../utils");

/**
 * @description Play the currently playing song
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args
 */
module.exports.run = async (client, message, args) => {
    try {
        const serverQueue = queue.get("queue");
        if (!serverQueue || !serverQueue.playing) {
            return message.channel.send(strings.noSongPlaying);
        }

        const nowPlaying = serverQueue.songs[0];
        return message.channel.send(strings.nowPlaying.replace("SONG_TITLE", nowPlaying.title).replace("url", nowPlaying.url));
    } catch (error) {
        // Log the error
        console.error("Error occurred while getting now playing song:", error);
        
        // Send the error to the specified text channel
        const errorChannelId = '1240780333826445372'; // Replace with your error channel ID
        const errorChannel = client.channels.cache.get(errorChannelId);
        if (errorChannel && errorChannel.type === 'text') {
            errorChannel.send("Error occurred while getting now playing song:", error);
        } else {
            console.error("Error channel not found or not a text channel.");
        }

        message.channel.send(strings.errorNowPlaying);
    }
};

module.exports.names = {
    list: ["np", "nowplaying","الان"]
};
