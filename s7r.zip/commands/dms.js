const strings = require("../strings.json");
const allowedUsers = require("../allowed.json").allowedUsers;

/** 
 * @description Sends DM messages to a specified text channel
 * @param {Discord.Client} client the Discord client instance
 * @param {Discord.Message} message the message received in DM
 */
module.exports.run = async (client, message) => {
    try {
        // Check if the message sender is allowed
        if (!allowedUsers.includes(message.author.id)) {
            console.log("Unauthorized user tried to send a DM to the bot:", message.author.tag);
            return; // Exit if not an allowed user
        }

        // Fetch the text channel where you want to send the message and sender information
        const targetChannelId = '1240789144289017928'; // Replace with the ID of your desired text channel
        const targetChannel = client.channels.cache.get(targetChannelId);
        
        // If the target channel is found and is a text channel
        if (targetChannel && targetChannel.type === 'text') {
            // Construct the message content with sender information
            const messageContent = `**DM from ${message.author.tag}:** ${message.content}`;
            
            // Send the message to the target text channel
            targetChannel.send(messageContent);
        } else {
            console.error("Target channel not found or not a text channel.");
        }
        
        // Now, send a confirmation DM to the message sender
        message.author.send("Your message has been successfully received and processed by the bot.");
    } catch (error) {
        // Log the error
        console.error("Error occurred while processing DM message:", error);
    }
};

module.exports.names = {
    list: ["dmHandler"],
};
