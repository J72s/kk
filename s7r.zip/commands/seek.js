const ytdl = require("ytdl-core");
const strings = require("../strings.json");
const utils = require("../utils");

/** 
 * @description Seek to a position in the currently playing song
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args args[0] must be a time in the format "mm:ss" (minutes:seconds)
 */
module.exports.run = async (client, message, args) => {
    // Check if a time argument is provided
    if (!args[0]) return message.channel.send(strings.noArgsTime);

    // Parse the time argument into minutes and seconds
    const timeArgs = args[0].split(":");
    const minutes = parseInt(timeArgs[0]);
    const seconds = parseInt(timeArgs[1]);

    // Calculate the total seek position in seconds
    const seekPosition = (minutes * 60) + seconds;

    // Get the server queue
    const serverQueue = queue.get("queue");

    // Check if there's a server queue and if it's playing
    if (!serverQueue || !serverQueue.playing || !serverQueue.connection || !serverQueue.connection.dispatcher) {
        return message.channel.send(strings.noSongPlaying);
    }

    // Check if the seek position is valid
    if (seekPosition < 0 || seekPosition > serverQueue.songs[0].duration) {
        return message.channel.send(strings.invalidSeekPosition);
    }

    // Seek to the specified position
    serverQueue.connection.dispatcher.end();
    serverQueue.seekPosition = seekPosition;

    return message.channel.send(strings.seekSuccess.replace("POSITION", args[0]));
};

module.exports.names = {
    list: ["seek"]
};
