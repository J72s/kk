///////////////////////////
///
// Importing the config.js file
const token = require('./config.js').token;

// Output the token to ensure it's retrieved correctly
console.log("Token from config.js:", token);

module.exports = {
    showTime: false, // Toggle to show or hide time in status (true/false)
    token: token,
    timeZone: "Asia/Kolkata", //Your Timezone, eg Asia/Kolkata
    Name: "Eric Music",
    State: "Just shut up",
    Details: "ُُEric bot",
    FirstButtonName: "My Server",
    FirstButtonUrl: "https://discord.gg/KGnvcT5A8V",
    LargeImage: "https://cdn.discordapp.com/attachments/1224387634411999233/1242686992966225991/774e9d079691267460d2fc37b920e23d.gif?ex=664ebdf3&is=664d6c73&hm=6146aa0a19999b27dfbbdbe6afadffc2264ea68393b4c82f5d2de46e2c9efe69&", // DISCORD CDN IMAGE ONLY
    LargeText: "Eric", // hover text for large image
    SmallImage: "https://cdn.discordapp.com/attachments/1224387634411999233/1242686992966225991/774e9d079691267460d2fc37b920e23d.gif?ex=664ebdf3&is=664d6c73&hm=6146aa0a19999b27dfbbdbe6afadffc2264ea68393b4c82f5d2de46e2c9efe69&", // DISCORD CDN IMAGE ONLY
    SmallText: "...", // hover text for small image
  };
  